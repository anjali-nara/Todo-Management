package net.anjali.todo_management.repository;

import net.anjali.todo_management.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRespository extends JpaRepository<Role, Long> {
    Role findByName(String name);

}
