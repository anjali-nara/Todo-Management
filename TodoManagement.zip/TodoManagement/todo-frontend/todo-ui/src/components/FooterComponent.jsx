import React from "react";

const FooterComponent=()=>{
    return(
        <div>
            <footer className="footer">
            <p className="text-center">@Copyrights reserved by Anjali</p>
            </footer>
            
        </div>
    )
}
export default FooterComponent